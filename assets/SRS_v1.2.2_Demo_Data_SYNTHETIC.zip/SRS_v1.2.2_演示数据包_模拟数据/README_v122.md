# SRS v1.2.2 演示数据包（模拟数据——仅供测试/演示）

- `site_A … site_E`：五个结论分支；课题三得分（03/04）为 v1.2.2 独立随机流 SeedSequence([20261009,122,k])，全部在等级定义域 [0,1] 内。
- `fixtures/`：8 份导入夹具；`fixtures/ssui_out_of_domain/`：v1.2.1 旧得分（A–E 生产/生态 10 份），其中 SSUI>1 的为域外回归夹具。
- `cases_v121/`：F（有机-重金属复合）、G（仅文献参考阈值）。
- `cases_v122/H/`：方案推荐 + 五阶段追溯（`attachments/` 为 6 份模拟材料 PDF，水印“模拟材料——仅供测试/演示, 非真实审批文件”）；`cases_v122/P/`：邻苯二甲酸酯单体/总量判定。
- `expected.json` / `metadata.json`：独立期望与文件指纹；`actual/`：Windows 实装程序（run 38093845656）的实际输出与 comparison.json。
- `generator/`：生成器、执行器、校验器与所用官方 CSV/权重；`validator_result.json`：独立校验结果。
- 重建：`python generator/mc_demo_v12.py generate --out <dir>`（需在 SRS 源码仓库中运行，见 D01/D02）。
