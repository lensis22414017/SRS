"""T03 end-to-end (local, real uvicorn server + file SQLite + built frontend), site A post-remediation.
Independent expectations come from the agreed Q09/Q17 behaviour, not from the code under test."""
import io, json, os, re, subprocess, sys, time, zipfile, shutil, socket
from openpyxl import load_workbook
from pypdf import PdfReader
W = os.environ["W"]; WT = os.path.join(W, "srs_wt"); OUT = os.path.join(W, "t03e2e", "out"); os.makedirs(OUT, exist_ok=True)
DB = os.path.join(W, "t03e2e", "srs_demo_t03.db"); shutil.copy2("/tmp/demo122/srs_demo_122.db", DB)
DATA = os.path.join(W, "t03e2e", "data"); shutil.rmtree(DATA, ignore_errors=True)
os.environ.update({"DATABASE_URL": "sqlite:///" + DB, "SRS_DATA_DIR": DATA, "SECRET_KEY": "demo_only_key_" + "x" * 40, "MPLBACKEND": "Agg"})
sys.path.insert(0, os.path.join(WT, "backend")); sys.path.insert(0, WT)
from fastapi.testclient import TestClient
from app.main import app
_tc = TestClient(app); _tc.__enter__(); requests = _tc; B = ""
checks = []
def check(name, cond, detail=None): checks.append({"check": name, "passed": bool(cond), "detail": detail})
try:
    r = requests.post(B + "/api/v1/auth/login", json={"username": "admin", "password": "Demo@Run2026x"}).json()
    tok, user = r["access_token"], r["user"]; H = {"Authorization": "Bearer " + tok}
    sites = requests.get(B + "/api/v1/sites", headers=H, params={"page_size": 100}).json()["items"]
    sid = [x["id"] for x in sites if "MCDEMO-A" in (x.get("name") or "")][0]
    U = f"{B}/api/v1/sites/{sid}/utilization"; P = "post_remediation"
    # invalid selections
    for nm, prm in (("farmland_type=旱地", {"farmland_type": "旱地"}), ("eco_land_class=生态用地", {"eco_land_class": "生态用地"})):
        rr = requests.post(U, headers=H, params={"stage": P, **prm}); check(f"[T03·API] 无效用途 {nm} → 422", rr.status_code == 422, rr.status_code)
    states = {
        "omitted": ({}, dict(prod="needs_manual_use_selection", eco="needs_manual_use_selection", formal_positive=False)),
        "eco_non_construction": ({"farmland_type": "水田", "eco_land_class": "非建设用地生态用途"},
                                 dict(prod="explicit", eco="regulatory_applicability_unresolved", eco_positive=False)),
        "explicit": ({"farmland_type": "水田", "eco_land_class": "第一类用地"}, dict(prod="explicit", eco="explicit", decision="both_supported")),
    }
    summary = {}
    for key, (prm, ex) in states.items():
        d = requests.post(U, headers=H, params={"stage": P, **prm}).json()
        us = d.get("use_state") or {}; ds = d.get("decision_state")
        summary[key] = {"params": prm, "decision_state": ds, "use_state": us, "hypothetical_screen": d.get("hypothetical_screen"),
                        "conclusion_text": d.get("conclusion_text"), "decision_id": d.get("decision_id")}
        check(f"[T03·API {key}] 生产用途状态 = {ex['prod']}", us.get("production") == ex["prod"], us)
        check(f"[T03·API {key}] 生态用途状态 = {ex['eco']}", us.get("ecology") == ex["eco"], us)
        if ex.get("formal_positive") is False:
            check(f"[T03·API {key}] 无正式正向结论", not str(ds).endswith("_supported"), ds)
        if ex.get("eco_positive") is False:
            check(f"[T03·API {key}] 无正式生态正向结论", ds not in ("both_supported", "ecology_supported"), ds)
        if ex.get("decision"):
            check(f"[T03·API {key}] 结论 = {ex['decision']}", ds == ex["decision"], ds)
        # exports
        sj = requests.get(f"{B}/api/v1/sites/{sid}/evaluation-snapshot", headers=H).json()
        su = (sj.get("snapshot") or {}).get("utilization", {}).get(P) or {}
        check(f"[T03·快照 {key}] 快照 use_state 与 API 一致", su.get("use_state") == us and su.get("state") == ds, {"snap": su.get("use_state"), "state": su.get("state")})
        xb = requests.get(f"{B}/api/v1/sites/{sid}/evaluation-snapshot.xlsx", headers=H).content
        open(os.path.join(OUT, f"A_{key}_snapshot.xlsx"), "wb").write(xb)
        wb = load_workbook(io.BytesIO(xb)); st_cn = su.get("state_cn") or ""
        ur = [r for r in wb["利用结论与用途"].iter_rows(values_only=True) if r[0] == "修复后"] if "利用结论与用途" in wb.sheetnames else []
        xmap = {"explicit": "已选择", "needs_manual_use_selection": "未选择", "regulatory_applicability_unresolved": "法规适用性未定"}
        okx = bool(ur) and ur[0][2] == ds and ur[0][3] == st_cn and str(ur[0][5]).startswith(xmap[us["production"]]) \
              and str(ur[0][7]).startswith(xmap[us["ecology"]]) and str(ur[0][8]).startswith("是" if su.get("hypothetical_screen") else "否")
        check(f"[T03·Excel {key}] Excel“利用结论与用途”表 = API(结论/用途/假设筛查)", okx, ur[0][2:9] if ur else None)
        for fmt in ("pdf", "docx"):
            rr = requests.post(f"{B}/api/v1/sites/{sid}/report?format={fmt}", headers=H); rid = rr.json().get("report_id") or rr.json().get("id")
            blob = requests.get(f"{B}/api/v1/reports/{rid}/download", headers=H).content
            fn = os.path.join(OUT, f"A_{key}_report.{fmt}"); open(fn, "wb").write(blob)
            if fmt == "pdf":
                txt = "".join((p.extract_text() or "") for p in PdfReader(fn).pages)
            else:
                z = zipfile.ZipFile(fn); txt = re.sub(r"<[^>]+>", "", z.read("word/document.xml").decode("utf-8"))
            txt = re.sub(r"\s+", "", txt)
            want = {"needs_manual_use_selection": "未选择", "regulatory_applicability_unresolved": "适用性未定", "explicit": "已选择"}
            need = [want[us.get("production")], want[us.get("ecology")], re.sub(r"\s+", "", st_cn)]
            if su.get("hypothetical_screen"): need.append("不构成正式利用结论")
            miss = [n for n in need if n not in txt]
            check(f"[T03·{fmt.upper()} {key}] 报告含用途状态与结论", not miss, {"missing": miss})
finally:
    _tc.__exit__(None, None, None)
n = len(checks); ok = sum(c["passed"] for c in checks)
json.dump({"commit_code": "6c4d73e (app code; ccc6ca8 = docs only)", "site": "SRS-A (synthetic, post_remediation)", "server": "FastAPI app in-process (TestClient) + SQLite file copy of local demo DB (macOS); UI verified separately on Windows runner",
           "summary": {"checks": n, "passed": ok, "failed": n - ok}, "states": summary, "checks": checks},
          open(os.path.join(OUT, "T03_e2e_result.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1, default=str)
print(n, ok); [print(c["passed"], c["check"], json.dumps(c["detail"], ensure_ascii=False)[:120]) for c in checks if not c["passed"]]
