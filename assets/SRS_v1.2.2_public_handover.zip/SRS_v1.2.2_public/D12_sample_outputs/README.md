# 样例输出（模拟数据）

Windows 实装 v1.2.2 程序（run 38093845656，提交 68a5275）对合成演示数据的实际输出：
- `A_report.pdf/.docx`、`A_evaluation_snapshot.xlsx/.json`：同一评价快照生成的报告与 Excel
- `A_S2_export_*.xlsx`、`A_S3_*_export_*.xlsx`：课题二/三批次导出
- `B–E_report.pdf`、`B–E_evaluation_snapshot.xlsx`：其余场景报告
- `H_*_trace_report.pdf/.docx`：场地 H 五阶段追溯报告（阶段→证据追溯表，模拟材料）；`H_persist_probe.json`：重启前状态探针
- `comparison.json`：全部比对项（含跨渠道一致性、场地 H 角色检查、案例 P、域外 SSUI 回放）
