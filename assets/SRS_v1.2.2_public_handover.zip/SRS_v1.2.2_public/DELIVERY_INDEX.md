# SRS v1.2.2-rc.1 public（可对外） 包索引

提交 `68a52751e8dfa6f6c48b5c20dd8b69b53b54e3b2`；run 38093845656。完整索引与哈希见 07_PACKAGES/DELIVERY_INDEX.md、SHA256SUMS.txt。

| 交付项 | 文件数 | 字节 | 内容 |
|---|---:|---:|---|
| D03_Windows_installer_portable | 6 | 577,463,437 | Windows 安装版与便携版（来自 Actions run，含 CI 原始 .sha256）；公开 ZIP 不内嵌二进制，见 GitHub Release 资产 |
| D04_screenshots | 3 | 6,522,177 | Windows 实装程序界面截图包（GitHub Actions 虚拟机） |
| D05_user_manual | 2 | 8,760,957 | 用户操作手册 DOCX/PDF |
| D06_presentation | 2 | 16,078,394 | 客户汇报四章版（由甲方母版重构）与年度验收演示公开版 |
| D07_demo_package | 1 | 5,684,541 | 合成演示数据包（A–E、F/G、H、P、夹具、期望、Windows 实际输出与比对） |
| D08_import_templates | 6 | 46,012 | 导入模板（修复前、课题二 28 项、课题三生产/生态） |
| D11_evidence | 126 | 20,862,128 | Windows 验收/标准账户/DOCX 渲染 JSON 与日志、CI 日志、本机测试、修复前复现 |
| D12_sample_outputs | 20 | 3,826,637 | 演示场地报告样例（PDF/DOCX）与比对 |
| D13_operator_script | 1 | 9,924 | 演示操作脚本 |
| D14_release_docs | 9 | 41,718 | 发布说明、变更记录、已知限制、迁移与回滚 |
| D16_continuation | 1 | 5,309 | 继续开发交接说明 |

公开 ZIP 不内嵌安装版/便携版二进制；请从 GitHub Release `v1.2.2-rc.1` 下载并按 D03 中 .sha256 校验。
