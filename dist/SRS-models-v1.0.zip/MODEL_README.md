# SRS ML 模型说明 v1.0

## 模型概述

| 属性 | 值 |
|------|-----|
| 模型名称 | rf_barrier_factor |
| 最新版本 | v0.1_20260613 |
| 算法 | RandomForestClassifier |
| 训练数据 | 真实数据集_20250731_n1119 |
| 污染类型 | 重金属 (HM) |
| 训练时间 | 2026-06-13 13:22 UTC |

## 超参数

```json
{
  "n_estimators": 300,
  "class_weight": "balanced",
  "random_state": 42
}
```

## 模型指标

| 指标 | 值 |
|------|-----|
| Accuracy | 0.9911 |
| F1-Score | 0.9655 |
| ROC-AUC | 0.9991 |
| Test Size | 224 |

### 空间分组验证 (group_split)

| 分组策略 | Test N | Balanced Accuracy | Macro F1 | ROC-AUC |
|----------|--------|-------------------|----------|---------|
| id_DOI | 6913 | 0.9995 | 0.9994 | 1.0 |
| id_Source | 5926 | 0.9995 | 0.9995 | 1.0 |

**重要警告**: 行级/分组指标均接近 1，优先解释为阈值派生标签与污染物特征强绑定，不能当作独立真实性能证据。AUC 参考值为主，实际应用关注 SHAP 特征重要性排序的稳定性。

## 特征清单 (16 原始 + 15 缺失指示)

### 污染物特征 (12)
- Cr, Hg, As, Pb, Cu, Zn, Ni, Cd (重金属)
- OCPs, PAHs, PCBs, PAEs (有机污染物)

### 土壤属性特征 (4)
- SoilBD (容重), SoilpH, BackgroundSOC (背景有机碳)
- SandPerc, SiltPerc, ClayPerc (质地)
- Fertilization_T, OC_T, N_T, P_T, K_C, SWC_T (肥力/水分)

### 缺失指示特征 (15)
以 `__missing` 后缀标记对应特征的缺失状态。

## 文件清单

| 文件 | 说明 |
|------|------|
| rf_barrier_factor_v0.1_20260613.joblib | 模型权重文件 (~1MB) |
| rf_barrier_factor_v0.1_20260613.meta.json | 元数据 (特征/指标/参数) |
| rf_group_split_metrics.json | 空间分组验证结果 |

## 加载代码

```python
import joblib
import json

# 加载模型
model = joblib.load("ml/artifacts/rf_barrier_factor_v0.1_20260613.joblib")

# 加载元数据
with open("ml/artifacts/rf_barrier_factor_v0.1_20260613.meta.json") as f:
    meta = json.load(f)

features = meta["feature_list"]
medians = meta["medians"]

# 预测
import numpy as np
X = np.array([[medians.get(f, 0) for f in features]])
proba = model.predict_proba(X)
```

## 模型版本管理

模型文件命名规范: `{model_name}_{version}_{date}.joblib`

- `model_name`: rf_barrier_factor (随机森林障碍因子分类器)
- `version`: v0.1 (原型版本)
- `date`: YYYYMMDD (训练日期)

每次重新训练产生新的 .joblib + .meta.json 文件对，旧版本保留作为历史参考。

## 已知限制

1. **AUC 虚高**: 标签由阈值规则派生，与输入特征高度共线，AUC 不能独立作为模型泛化能力证据。
2. **缺失率偏高**: 非污染物特征（土壤属性）覆盖率仅 ~18%，大量使用中位数填补。
3. **时空代表性有限**: 训练数据以个旧重金属场地为主，外推到其他地区/污染类型需谨慎。
4. **单标签 (HM)**: 当前模型仅适用于重金属污染场景，有机污染/复合污染需重新训练。
